# Project Taiyi 工作流

## 开始工作

先读 `AGENTS.md` 和 [工作区入口](WORKSPACE.md)，确认任务所属目录。改文件前检查 `git status --short`，保留既有未提交内容。当前实跑摘要是 [S14](records/memory/session-14.md)（第四话已开始；停在周六凌晨，欲子获梁文川送医生还，铜锅与银行查档未完成）；新记录到来后以最新原文为准。

## 资料职责

| 内容 | 位置与依据 |
|---|---|
| 公开 Wiki | `src/` Markdown；侧栏 `src/.vitepress/sidebar.json` |
| 实跑证据 | `records/` 原逐字稿；`records/memory/` 摘要、状态、实体、奖励 |
| 世界观与 NPC | `campaign/world/`、`campaign/npcs/`；见各分类索引 |
| 当前设计决定 | `campaign/decisions/`；历史审阅在 `campaign/archive/` |
| 各话梗概 | `campaign/episodes/` |
| 单场备团与完整模组 | `campaign/prep/sessions/`、`campaign/prep/modules/` |
| 本地图片与工程 | `assets/`；NPC 采用状态以 `assets/npc/production/control/portrait-master.json` 为准 |
| Foundry 材料 | `foundry/`；工具 `scripts/fvtt/`；具体流程见 `FVTT_MAINTENANCE.md` |
| 工作审计与生成报告 | `maintenance/`；临时文件 `temp/` |

原始逐字稿不改写。NPC 当前设定、玩家已经知道的事、未来计划分开记录。历史生成请求、manifest 和部署快照不为迎合当前姓名或路径重写；旧路径用 `scripts/workspace/locate.py` 查询。

## 常见工作

- 补录：按 `records/memory/templates/session-template.md` 写摘要，同步 `records/README.md`、当前状态、实体、奖励。发生了什么依据原文，不从预案倒填。
- 设计与备团：先读[写作规范](campaign/guides/写作规范.md)与[模组写作规范](campaign/guides/模组写作规范.md)，按任务控制篇幅。备团默认简洁、可用的故事骨架，写入 `campaign/prep/`，更新备团索引。
- NPC：先看 `campaign/npcs/index.md`。重要人物正文写 `stories/`；名录与出场写 `roster/`；职业、关系、外观参考写 `reference/`；旧版本写 `archive/`。
- 资产：保留原图和接受过的版本，记录当前候选／采用状态。不要将未知根目录文件凭空赋予人物身份。
- Wiki：直接维护 `src/`，新页面同步侧栏，不使用旧转换脚本。

## 验证

| 变更 | 检查 |
|---|---|
| 记录／设定／备团 | 对照原始证据，检查相对链接；不要把新计划记成事实 |
| 工作区结构 | `python scripts/workspace/check.py`；旧路径查询工具可用于历史快照 |
| NPC 与二十话 | `node scripts/validate-campaign-npc-restructure.mjs`；区分已有问题和新问题 |
| 立绘控制与本地审阅页 | `node assets/npc/production/tools/validate-control.mjs`；需要时运行同目录 `start-review.cmd` 检查界面 |
| Wiki 链接 | `python scripts/check-links.py`，报告写到 `maintenance/reports/wiki-link-report.txt` |
| 公开页面／导航／主题 | `npm run build`；视觉改动再做运行检查 |
| Foundry | 按维护说明校验 JSON、路径与真实运行；本地修改不等于线上部署 |

交付说明改了什么、验证了什么、尚未确认什么。只归档已明确识别的资料，不删除不明文件，也不混入无关提交。
