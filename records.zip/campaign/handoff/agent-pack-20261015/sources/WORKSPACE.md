# 龙散战记工作区

2026-09-11 整理，2026-10-10 更新实跑入口。先按用途找资料，再看文件中的时间与状态。GM 资料与公开 Wiki 分开维护。

| 要做什么 | 从哪里开始 |
|---|---|
| 看最新跑到哪里 | [战役当前状态](records/memory/campaign-state.md)、[S14 摘要](records/memory/session-14.md) |
| 核对原话、奖励和人物见闻 | [实跑记录索引](records/README.md) |
| 准备下一场 | [S14 待接续事项](records/memory/session-14.md#待接续事项)、[第四话场景梗概](campaign/prep/sessions/ep04-场景梗概.md)、[场景梗概样板](campaign/prep/sessions/ep04-义胜盟-新故事.md)、[备团索引与旧稿](campaign/prep/README.md)、[NPC 反应表](campaign/prep/sessions/ep04-已出场NPC反应表.md) |
| 看二十话与当前定案 | [战役创作入口](campaign/README.md)、[各话索引](campaign/episodes/README.md)、[设计定案](campaign/decisions/二十话重整-设计定案.md) |
| 查人物设定、组织与出场 | [NPC 总索引](campaign/npcs/index.md) |
| 查世界观与城市背景 | [世界观索引](campaign/world/README.md) |
| 找立绘、地图、背景和群像 | [美术资产索引](assets/README.md) |
| 找人物卡、场景与导入报告 | [Foundry 本地材料](foundry/README.md) |
| 查技术工作记录、旧方案 | [维护资料](maintenance/README.md)、[战役旧稿](campaign/archive/README.md)、[早期 Wiki 方案](archive/wiki-design/README.md) |
| 修改玩家手册 | [公开站点首页](src/index.md)、[开发工作流](RUNBOOK.md) |
| 查玩家角色卡 | [角色卡目录](character_sheet/README.md) |

## 文件放置规则

- `records/`：已经发生的事。根目录保留原逐字稿，`memory/` 保存摘要、状态、实体与奖励记录。新计划不放这里。
- `campaign/`：世界观、NPC 设定、设计定案、分话梗概、单场备团和创作规范。未来安排不回填为实跑事实。
- `assets/`：本地美术资产与生产工程。保留母版、候选、审核状态和原始生成批次；发布图片仍由 `src/portraits/` 管理。
- `foundry/`：人物卡、场景、导入清单、部署与运行验证材料。工具代码继续放 `scripts/fvtt/`。
- `maintenance/`：工作审计、备份、验证报告与迁移清单。`temp/` 只存临时工作，不作为正式资料入口。
- `src/`：实际发布到 VitePress 的玩家手册。内容与导航按既有工作流维护。

未知用途的根目录图片已放入 [待归类图片](assets/inbox/README.md)，保留原名，不猜测身份或采用状态。已知六人聚餐版本在 [群像资料](assets/group-portraits/README.md)。

旧路径查询见 [迁移说明](maintenance/workspace-20260911/README.md)。历史生成清单、请求和部署快照保留当时路径；可用 `python scripts/workspace/locate.py <旧路径>` 找到当前位置。
