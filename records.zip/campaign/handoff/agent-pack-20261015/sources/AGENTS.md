# AGENTS.md

This file provides guidance to Codex (Codex.ai/code) when working with code in this repository.

## Project Overview

**Project Taiyi** is a VitePress-based wiki for *龙散战记 · 玩家手册* (Longsan Chronicles - Player's Manual), a tabletop RPG rulebook built on Savage Worlds Adventure Edition (SWADE) adapted to a near-future cyberpunk setting (Longsan City, 2030). The site is published to GitHub Pages.

Before non-trivial Codex work, read `RUNBOOK.md` for the current workflow map, output-shape defaults, transcript grounding expectations, and verification matrix. Use `FVTT_MAINTENANCE.md` for Foundry-specific maintenance details rather than duplicating them here.

## Commands

```bash
npm run dev       # Start local dev server (hot reload)
npm run build     # Build static site to src/.vitepress/dist/
npm run preview   # Preview the built site locally
```

Deployment is automatic via GitHub Actions on push to `main` — no manual deploy step needed.

## Architecture

### Content Workflow

All content is maintained **directly as Markdown files** in `src/`. Do not use the archived conversion scripts in `archive/`.

- **`src/index.md`** — Homepage
- **`src/核心规则/`** — All rulebook content, organized into subdirectories by chapter/topic

### Sidebar

The sidebar is defined in **`src/.vitepress/sidebar.json`** and loaded by `src/.vitepress/config.mjs`. When adding or renaming pages, update `sidebar.json` manually to reflect the new link.

### Key Directories

| Path | Purpose |
|------|---------|
| `src/核心规则/角色/` | Character creation: hindrances (`负赘.md`), attributes & skills (`特性/`), edges (`专长/`, 7 categories), advancement |
| `src/核心规则/装备/` | Equipment notes and shop listings (`装备/商店/`) with inventories and prices |
| `src/核心规则/规则/` | Core rules: combat, situational rules (`情景规则/`), extras |
| `src/核心规则/冒险工具箱/` | GM toolkit: chases, social conflict, wealth, downtime, hazards (`危难/`) |
| `src/核心规则/奇能/` | Powers system, four schools, power lists |
| `src/核心规则/龙散市/` | Player-facing city wiki: districts, PC/NPC cards, organization index |
| `src/portraits/` | Published character portraits (webp), referenced by `龙散市/` pages |
| `src/.vitepress/` | VitePress config, sidebar JSON, theme |
| `scripts/` | Utility scripts for link checking and content maintenance |
| `scripts/fvtt/` | Foundry VTT helper scripts (gitignored, local) |
| `archive/` | Archived one-shot conversion scripts — do not use |
| `records/` | Actual-play transcripts and structured session evidence only (gitignored) |
| `character_sheet/` | Example player character sheets (gitignored) |
| `campaign/` | World, NPCs, episodes and session preparation (gitignored) |
| `assets/` | Local art production and source assets (gitignored) |
| `foundry/` | Foundry import, scene and runtime materials (gitignored) |
| `maintenance/` | Work audits, backups and generated reports (gitignored) |

### Scripts

Located in `scripts/` — these are utility tools for content maintenance:

- `check-links.py` — validates internal links across markdown files
- `fix-bold-italic.js` — fixes markdown bold/italic formatting
- `merge_skills.py` — merges skill entries
- `sort_edges.py` — sorts edge entries by category
- `update_skill_links.py` — updates cross-references between skill pages

### Content Language

All content is in **Simplified Chinese (zh-CN)**. Edge names typically appear in Chinese with an English transliteration in parentheses. Prices use ¥ (yuan) currency.

## Workspace organization

Read `WORKSPACE.md` for current locations. Session plans belong in `campaign/prep/`; NPC setting files belong in `campaign/npcs/`. `records/` is reserved for played facts. Do not recreate `discussion/` or `records/prep/`; use `scripts/workspace/locate.py` for historical paths.
